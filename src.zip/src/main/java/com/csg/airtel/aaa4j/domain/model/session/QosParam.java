package com.csg.airtel.aaa4j.domain.model.session;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class QosParam {
    private String normalBandwidth;
    private String fupBandwidth;
}
