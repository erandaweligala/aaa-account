package com.csg.airtel.aaa4j.domain.service;


import com.csg.airtel.aaa4j.domain.model.AccountingRequestDto;
import com.csg.airtel.aaa4j.domain.model.AccountingResponseEvent;
import com.csg.airtel.aaa4j.domain.model.ServiceBucketInfo;
import com.csg.airtel.aaa4j.domain.model.session.Balance;
import com.csg.airtel.aaa4j.domain.model.session.Session;
import com.csg.airtel.aaa4j.domain.model.session.UserSessionData;
import com.csg.airtel.aaa4j.domain.produce.AccountProducer;
import com.csg.airtel.aaa4j.external.clients.CacheClient;
import com.csg.airtel.aaa4j.external.repository.UserBucketRepository;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.jboss.logging.Logger;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


@ApplicationScoped
public class StartHandler {
    private static final Logger log = Logger.getLogger(StartHandler.class);
    private final CacheClient utilCache;
    private final UserBucketRepository userRepository;
    private final AccountProducer  accountProducer;
    private final AccountingUtil accountingUtil;

    @Inject
    public StartHandler(CacheClient utilCache, UserBucketRepository userRepository, AccountProducer accountProducer, AccountingUtil accountingUtil) {
        this.utilCache = utilCache;
        this.userRepository = userRepository;
        this.accountProducer = accountProducer;
        this.accountingUtil = accountingUtil;
    }

    public Uni<Void> processAccountingStart(AccountingRequestDto request,String traceId) {
        long startTime = System.currentTimeMillis();
        log.infof("[traceId: %s] Processing accounting start for user: %s, sessionId: %s",
                traceId, request.username(), request.sessionId());
//todo need improve performance and used best practise and optimize this code and fixed sonar issues
    return utilCache.getUserData(request.username())
            .onItem().invoke(userData ->
                    log.infof("[traceId: %s]User data retrieved for user: %s",traceId, request.username()))
            .onItem().transformToUni(userSessionData -> {
                if (userSessionData == null) {
                    log.infof("[traceId: %s] No cache entry found for user: %s", traceId,request.username());
                    Uni<Void> accountingResponseEventUni = handleNewUserSession(request);

                    long duration = System.currentTimeMillis() - startTime;
                    log.infof("[traceId: %s] Completed processing accounting start for user: %s in %d ms",
                            traceId, request.username(), duration);
                    return accountingResponseEventUni;
                } else {
                    log.infof("[traceId: %s] Existing session found for user: %s",traceId, request.username());
                    Uni<Void> accountingResponseEventUni = handleExistingUserSession(request, userSessionData);
                    long duration = System.currentTimeMillis() - startTime;
                    log.infof("[traceId: %s] Completed processing accounting start for user: %s in %d ms",
                            traceId, request.username(), duration);
                    return accountingResponseEventUni;
                }
            })
            .onFailure().recoverWithUni(throwable -> {
                log.errorf(throwable, "[traceId: %s] Error processing accounting start for user: %s", traceId, request.username());
                return Uni.createFrom().voidItem();
            });
}

    private Uni<Void> handleExistingUserSession(
            AccountingRequestDto request,
            UserSessionData userSessionData) {

        // Declare balanceListUni outside the if block
        Uni<List<Balance>> balanceListUni;

        String groupId = userSessionData.getGroupId();
        boolean isGroupUser = groupId != null && !groupId.equals("1");

        if (isGroupUser) {
            balanceListUni = utilCache.getUserData(groupId)
                    .onItem()
                    .transform(UserSessionData::getBalance);
        } else {
            // Use the user's own balance list if groupId is "1" or null
            balanceListUni = Uni.createFrom().item(userSessionData.getBalance());
        }

        // Chain the balance calculation to handle the asynchronous Uni
        return balanceListUni.onItem().transformToUni(balanceList -> {
            // Combine user's balance with the additional balance list
            List<Balance> combinedBalances = new ArrayList<>(userSessionData.getBalance());
            if (balanceList != null && !balanceList.isEmpty()) {
                combinedBalances.addAll(balanceList);
            }

            double availableBalance = calculateAvailableBalance(combinedBalances);

            if (availableBalance <= 0) {
                log.warnf("User: %s has exhausted their data balance. Cannot start new session.",
                        request.username());
                return accountProducer.produceAccountingResponseEvent(
                        MappingUtil.createResponse(request, "Data balance exhausted",
                                AccountingResponseEvent.EventType.COA,
                                AccountingResponseEvent.ResponseAction.DISCONNECT));
            }

            boolean sessionExists = userSessionData.getSessions()
                    .stream()
                    .anyMatch(session -> session.getSessionId().equals(request.sessionId()));

            if (sessionExists) {
                log.infof("[traceId: %s] Session already exists for user: %s, sessionId: %s",
                        request.username(), request.sessionId());
                return Uni.createFrom().voidItem();
            }

            // Check if the highest priority balance is a group balance
            // If so, also add the session to group session data
            return accountingUtil.findBalanceWithHighestPriority(combinedBalances, null)
                    .onItem().transformToUni(highestPriorityBalance -> {
                        if (highestPriorityBalance == null) {
                            log.warnf("No valid balance found for user: %s. Cannot start new session.",
                                    request.username());
                            return accountProducer.produceAccountingResponseEvent(
                                    MappingUtil.createResponse(request, "No valid balance found",
                                            AccountingResponseEvent.EventType.COA,
                                            AccountingResponseEvent.ResponseAction.DISCONNECT));
                        }

                        // Add new session and update cache
                        Session newSession = createSession(request);
                        newSession.setPreviousUsageBucketId(highestPriorityBalance.getBucketId());
                        if(!isGroupBalance(highestPriorityBalance,request.username())) {
                            userSessionData.getSessions().add(newSession);
                        }

                        // Check if highest priority balance is a group balance
                        boolean isHighestPriorityGroupBalance = isGroupBalance(highestPriorityBalance, request.username());
                        //String groupId = userSessionData.getGroupId();

                        Uni<Void> updateUni;

                        if (isHighestPriorityGroupBalance && groupId != null && !groupId.equals("1")) {
                            // If highest priority is group balance, also add session to group data
                            log.infof("Highest priority balance is a group balance. Adding session to group data for groupId: %s", groupId);

                            updateUni = utilCache.getUserData(groupId)
                                    .onItem().transformToUni(groupSessionData -> {
                                        if (groupSessionData != null) {
                                            if (groupSessionData.getSessions() == null) {
                                                groupSessionData.setSessions(new ArrayList<>());
                                            }
                                            groupSessionData.getSessions().add(newSession);

                                            // Update both user and group caches
                                            return Uni.combine().all().unis(
                                                    utilCache.updateUserAndRelatedCaches(request.username(), userSessionData),
                                                    utilCache.updateUserAndRelatedCaches(groupId, groupSessionData)
                                            ).discardItems()
                                                    .onItem().invoke(unused ->
                                                            log.infof("Session added to both user: %s and group: %s", request.username(), groupId));
                                        } else {
                                            // Group data not found, just update user data
                                            log.warnf("Group data not found for groupId: %s. Only updating user data.", groupId);
                                            return utilCache.updateUserAndRelatedCaches(request.username(), userSessionData);
                                        }
                                    })
                                    .replaceWithVoid();
                        } else {
                            // Normal balance, only update user data
                            updateUni = utilCache.updateUserAndRelatedCaches(request.username(), userSessionData)
                                    .onItem().invoke(unused ->
                                        log.infof("[traceId: %s] New session added for user: %s, sessionId: %s",
                                                request.username(), request.sessionId()))
                                    .replaceWithVoid();
                        }

                        return updateUni
                                .invoke(() -> {
                                    log.infof("cdr write event started for user: %s", request.username());
                                    // Send CDR event asynchronously
                                    generateAndSendCDR(request, newSession);
                                })
                                .onFailure().recoverWithUni(throwable -> {
                                    log.errorf(throwable, "Failed to update cache for user: %s", request.username());
                                    return Uni.createFrom().voidItem();
                                });
                    });
        });

    }


    private Uni<Void> handleNewUserSession(AccountingRequestDto request) {
        log.infof("No existing session data found for user: %s. Creating new session data.",
                request.username());

        return userRepository.getServiceBucketsByUserName(request.username())
                .onItem().transformToUni(serviceBuckets -> {
                    if (serviceBuckets == null || serviceBuckets.isEmpty()) {
                        log.warnf("No service buckets found for user: %s. Cannot create session data.",
                                request.username());
                        return accountProducer.produceAccountingResponseEvent(
                                        MappingUtil.createResponse(request, "No service buckets found",
                                                AccountingResponseEvent.EventType.COA,
                                                AccountingResponseEvent.ResponseAction.DISCONNECT))
                                .replaceWithVoid();
                    }

                    double totalQuota = 0.0;
                    List<Balance> balanceList = new ArrayList<>(serviceBuckets.size());
                    List<Balance> balanceGroupList = new ArrayList<>();
                    String groupId = null;

                    for (ServiceBucketInfo bucket : serviceBuckets) {
                        Balance balance = MappingUtil.createBalance(bucket);

                        groupId = getGroupId(request, bucket, balanceGroupList, balance, groupId, balanceList);
                        totalQuota += bucket.getCurrentBalance();
                    }

                    // Check quota early to fail fast
                    if (totalQuota <= 0) {
                        log.warnf("User: %s has zero total data quota. Cannot create session data.",
                                request.username());
                        return accountProducer.produceAccountingResponseEvent(
                                        MappingUtil.createResponse(request, "Data quota is zero",
                                                AccountingResponseEvent.EventType.COA,
                                                AccountingResponseEvent.ResponseAction.DISCONNECT))
                                .replaceWithVoid();
                    }


                    // Combine balances and find highest priority
                    List<Balance> combinedBalances = new ArrayList<>(balanceList);
                    if (!balanceGroupList.isEmpty()) {
                        combinedBalances.addAll(balanceGroupList);
                    }

                    String finalGroupId1 = groupId;
                    return accountingUtil.findBalanceWithHighestPriority(combinedBalances, null)
                            .onItem().transformToUni(highestPriorityBalance -> {
                                if (highestPriorityBalance == null) {
                                    log.warnf("No valid balance found for user: %s. Cannot create session data.",
                                            request.username());
                                    return accountProducer.produceAccountingResponseEvent(
                                                    MappingUtil.createResponse(request, "No valid balance found",
                                                            AccountingResponseEvent.EventType.COA,
                                                            AccountingResponseEvent.ResponseAction.DISCONNECT))
                                            .replaceWithVoid();
                                }

                                UserSessionData newUserSessionData = new UserSessionData();
                                newUserSessionData.setGroupId(finalGroupId1);
                                newUserSessionData.setUserName(request.username());
                                Session session = createSession(request);
                                session.setPreviousUsageBucketId(highestPriorityBalance.getBucketId());
                                if(!isGroupBalance(highestPriorityBalance,request.username())) {
                                    newUserSessionData.setSessions(new ArrayList<>(List.of(session)));
                                }
                                newUserSessionData.setBalance(balanceList);

                                Uni<Void> userStorageUni = utilCache.storeUserData(request.username(), newUserSessionData)
                                        .onItem().invoke(unused ->
                                                log.infof("New user session data created and stored for user: %s", request.username()))
                                        .replaceWithVoid();

                                if (!balanceGroupList.isEmpty()) {
                                    UserSessionData groupSessionData = new UserSessionData();
                                    groupSessionData.setBalance(balanceGroupList);

                                    // Check if the highest priority balance is a group balance
                                    boolean isHighestPriorityGroupBalance = isGroupBalance(highestPriorityBalance, request.username());

                                    final String finalGroupId = finalGroupId1;

                                    Uni<Void> groupStorageUni = utilCache.getUserData(finalGroupId1)
                                            .chain(existingData -> {
                                                if (existingData == null) {
                                                    // If highest priority is group balance, add session to group data
                                                    if (isHighestPriorityGroupBalance) {
                                                        groupSessionData.setSessions(new ArrayList<>(List.of(session)));
                                                        log.infof("Adding session to new group data for groupId: %s (highest priority balance is group balance)", finalGroupId);
                                                    } else {
                                                        groupSessionData.setSessions(new ArrayList<>());
                                                    }
                                                    return utilCache.storeUserData(finalGroupId, groupSessionData)
                                                            .onItem().invoke(unused -> log.infof("Group session data stored for groupId: %s", finalGroupId))
                                                            .onFailure().invoke(failure -> log.errorf(failure, "Failed to store group data for groupId: %s", finalGroupId));
                                                } else {
                                                    // If highest priority is group balance, add session to existing group data
                                                    if (isHighestPriorityGroupBalance) {
                                                        if (existingData.getSessions() == null) {
                                                            existingData.setSessions(new ArrayList<>());
                                                        }
                                                        existingData.getSessions().add(session);
                                                        log.infof("Adding session to existing group data for groupId: %s (highest priority balance is group balance)", finalGroupId);
                                                    }
                                                    log.infof("Group session data already exists for groupId: %s", finalGroupId);
                                                    return utilCache.updateUserAndRelatedCaches(finalGroupId, existingData)
                                                            .onItem().invoke(unused -> log.infof("Existing group session data updated for groupId: %s", finalGroupId));
                                                }
                                            });

                                    // Execute both storage operations in parallel
                                    userStorageUni = Uni.combine().all().unis(userStorageUni, groupStorageUni)
                                            .discardItems();
                                }

                                // Send CDR event asynchronously (fire and forget) after user storage
                                return userStorageUni.onItem().invoke(unused -> {
                                    log.infof("CDR write event started for user: %s", request.username());
                                    generateAndSendCDR(request, session);
                                });
                            });
                })
                .onFailure().recoverWithUni(throwable -> {
                    log.errorf(throwable, "Error creating new user session for user: %s",
                            request.username());
                    return Uni.createFrom().voidItem();
                });
    }

    private static String getGroupId(AccountingRequestDto request, ServiceBucketInfo bucket, List<Balance> balanceGroupList, Balance balance, String groupId, List<Balance> balanceList) {
        if (!Objects.equals(request.username(), bucket.getBucketUser())) {
            balanceGroupList.add(balance);
            groupId = bucket.getBucketUser();
        } else {
            balanceList.add(balance);
        }
        return groupId;
    }

    /**
     * Check if a balance belongs to a group (not owned by the current user).
     */
    private boolean isGroupBalance(Balance balance, String username) {
        return balance.isGroup() ||
               (balance.getBucketUsername() != null &&
                !balance.getBucketUsername().equals(username));
    }

    private double calculateAvailableBalance(List<Balance> balanceList) {
        return balanceList.stream()
                .mapToDouble(Balance::getQuota)
                .sum();
    }

    private Session createSession(AccountingRequestDto request) {
        return new Session(
                request.sessionId(),
                LocalDateTime.now(),
                null,
                0,
                0L,
                request.framedIPAddress(),
                request.nasIP()
        );
    }

    private void generateAndSendCDR(AccountingRequestDto request, Session session) {
        CdrMappingUtil.generateAndSendCDR(request, session, accountProducer, CdrMappingUtil::buildStartCDREvent);
    }



}
