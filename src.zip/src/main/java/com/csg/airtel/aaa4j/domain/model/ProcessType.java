package com.csg.airtel.aaa4j.domain.model;

public enum ProcessType {
    COA,
    DISCONNECT,
    STOP_ONLY
}
