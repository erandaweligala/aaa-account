package com.csg.airtel.aaa4j.domain.model;

public enum EventType {
    CREATE_EVENT,
    UPDATE_EVENT,
}
