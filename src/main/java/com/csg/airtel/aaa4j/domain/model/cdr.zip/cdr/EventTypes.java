package com.csg.airtel.aaa4j.domain.model.cdr;

public enum EventTypes {
    ACCOUNTING_START,
    ACCOUNTING_STOP,
    ACCOUNTING_INTERIM,
    ACCOUNTING_COA
}
